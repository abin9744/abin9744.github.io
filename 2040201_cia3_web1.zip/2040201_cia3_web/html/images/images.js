export default [
    "background1.jpg",
    "background2.jpg",
    "background3.jpg",
    "geeksimage1.png",
    "geeksimage2.png",
    "geeksimage3.png",
    "gfg1.png" 
  ];