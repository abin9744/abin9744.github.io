export default [
    "christ.jpg",
    "christ.jpg",
    
  ];